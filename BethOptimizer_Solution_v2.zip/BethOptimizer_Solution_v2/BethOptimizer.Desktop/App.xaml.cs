using System.Windows;
namespace BethOptimizer.Desktop { public partial class App : Application { } }