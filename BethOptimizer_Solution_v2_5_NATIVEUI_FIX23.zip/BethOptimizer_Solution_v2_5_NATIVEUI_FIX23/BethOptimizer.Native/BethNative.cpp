
#include <windows.h>
#include <dxgi1_6.h>
#include <string>
#include <vector>
#include <sstream>

#pragma comment(lib, "dxgi.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "advapi32.lib")

static void wcopy(const std::wstring& s, wchar_t* buffer, int capacity) {
    if (!buffer || capacity <= 0) return;
    int n = (int)std::min<size_t>(s.size(), (size_t)(capacity - 1));
    wcsncpy_s(buffer, capacity, s.c_str(), n);
    buffer[n] = L'\0';
}

extern "C" __declspec(dllexport) int GetPrimaryMonitorHz()
{
    // Find primary display device
    DISPLAY_DEVICEW dd = { sizeof(dd) };
    std::wstring devName;
    for (DWORD i = 0; EnumDisplayDevicesW(nullptr, i, &dd, 0); ++i) {
        if (dd.StateFlags & DISPLAY_DEVICE_PRIMARY_DEVICE) {
            devName = dd.DeviceName;
            break;
        }
    }

    DEVMODEW dm = {};
    dm.dmSize = sizeof(dm);
    if (!devName.empty()) {
        if (EnumDisplaySettingsExW(devName.c_str(), ENUM_CURRENT_SETTINGS, &dm, 0)) {
            return (int)dm.dmDisplayFrequency;
        }
    }
    // Fallback: primary display by NULL
    if (EnumDisplaySettingsExW(nullptr, ENUM_CURRENT_SETTINGS, &dm, 0)) {
        return (int)dm.dmDisplayFrequency;
    }
    return 0;
}

extern "C" __declspec(dllexport) int GetAllMonitorsHzJSON(wchar_t* buffer, int capacity)
{
    std::wstringstream json;
    json << L"{\"monitors\":[";
    bool first = true;

    DISPLAY_DEVICEW dd = { sizeof(dd) };
    for (DWORD i = 0; EnumDisplayDevicesW(nullptr, i, &dd, 0); ++i) {
        if (!(dd.StateFlags & DISPLAY_DEVICE_ACTIVE)) continue;
        bool primary = (dd.StateFlags & DISPLAY_DEVICE_PRIMARY_DEVICE) != 0;

        DEVMODEW dm = {}; dm.dmSize = sizeof(dm);
        int hz = 0;
        if (EnumDisplaySettingsExW(dd.DeviceName, ENUM_CURRENT_SETTINGS, &dm, 0)) {
            hz = (int)dm.dmDisplayFrequency;
        }
        if (!first) json << L","; first = false;
        json << L"{\"name\":\"" << dd.DeviceName << L"\",\"primary\":"
             << (primary ? L"true" : L"false") << L",\"hz\":" << hz << L"}";
    }
    json << L"]}";

    auto s = json.str();
    wcopy(s, buffer, capacity);
    return (int)s.size();
}

extern "C" __declspec(dllexport) int GetGpuName(wchar_t* buffer, int capacity)
{
    IDXGIFactory1* pFactory = nullptr;
    if (FAILED(CreateDXGIFactory1(__uuidof(IDXGIFactory1), (void**)&pFactory)))
        return 0;

    SIZE_T bestMem = 0;
    std::wstring bestName = L"";

    IDXGIAdapter1* pAdapter = nullptr;
    for (UINT i = 0; pFactory->EnumAdapters1(i, &pAdapter) != DXGI_ERROR_NOT_FOUND; ++i) {
        DXGI_ADAPTER_DESC1 desc;
        if (SUCCEEDED(pAdapter->GetDesc1(&desc))) {
            if (desc.Flags & DXGI_ADAPTER_FLAG_SOFTWARE) { pAdapter->Release(); continue; }
            if (desc.DedicatedVideoMemory >= bestMem) {
                bestMem = desc.DedicatedVideoMemory;
                bestName = desc.Description;
            }
        }
        pAdapter->Release();
    }
    pFactory->Release();
    wcopy(bestName, buffer, capacity);
    return (int)bestName.size();
}

extern "C" __declspec(dllexport) int GetGpuVramGB()
{
    IDXGIFactory1* pFactory = nullptr;
    if (FAILED(CreateDXGIFactory1(__uuidof(IDXGIFactory1), (void**)&pFactory)))
        return 0;

    SIZE_T bestMem = 0;
    IDXGIAdapter1* pAdapter = nullptr;
    for (UINT i = 0; pFactory->EnumAdapters1(i, &pAdapter) != DXGI_ERROR_NOT_FOUND; ++i) {
        DXGI_ADAPTER_DESC1 desc;
        if (SUCCEEDED(pAdapter->GetDesc1(&desc))) {
            if (desc.Flags & DXGI_ADAPTER_FLAG_SOFTWARE) { pAdapter->Release(); continue; }
            if (desc.DedicatedVideoMemory >= bestMem) {
                bestMem = desc.DedicatedVideoMemory;
            }
        }
        pAdapter->Release();
    }
    pFactory->Release();
    return (int)(bestMem / (1024ULL * 1024ULL * 1024ULL));
}

extern "C" __declspec(dllexport) int GetCpuName(wchar_t* buffer, int capacity)
{
    HKEY hKey;
    if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, L"HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0", 0, KEY_READ, &hKey) != ERROR_SUCCESS)
        return 0;
    wchar_t val[256]; DWORD size = sizeof(val);
    DWORD type = 0;
    int len = 0;
    if (RegQueryValueExW(hKey, L"ProcessorNameString", nullptr, &type, (LPBYTE)val, &size) == ERROR_SUCCESS && type == REG_SZ) {
        std::wstring s(val);
        wcopy(s, buffer, capacity);
        len = (int)s.size();
    }
    RegCloseKey(hKey);
    return len;
}

extern "C" __declspec(dllexport) int GetLogicalCores()
{
    return (int)GetActiveProcessorCount(ALL_PROCESSOR_GROUPS);
}

extern "C" __declspec(dllexport) int GetPhysicalCores()
{
    DWORD len = 0;
    GetLogicalProcessorInformationEx(RelationProcessorCore, nullptr, &len);
    if (GetLastError() != ERROR_INSUFFICIENT_BUFFER) return 0;
    std::vector<BYTE> buf(len);
    if (!GetLogicalProcessorInformationEx(RelationProcessorCore, (PSYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX)buf.data(), &len))
        return 0;
    int count = 0;
    BYTE* ptr = buf.data();
    BYTE* end = buf.data() + len;
    while (ptr < end) {
        auto info = (PSYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX)ptr;
        if (info->Relationship == RelationProcessorCore) count++;
        ptr += info->Size;
    }
    return count;
}

extern "C" __declspec(dllexport) int GetRamGB()
{
    MEMORYSTATUSEX ms = { sizeof(ms) };
    if (!GlobalMemoryStatusEx(&ms)) return 0;
    return (int)(ms.ullTotalPhys / (1024ULL * 1024ULL * 1024ULL));
}
