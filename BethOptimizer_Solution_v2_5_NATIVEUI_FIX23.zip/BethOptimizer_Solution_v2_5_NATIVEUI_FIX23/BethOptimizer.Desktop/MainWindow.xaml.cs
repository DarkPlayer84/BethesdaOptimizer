using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows;
using Microsoft.Win32;

namespace BethOptimizer.Desktop
{
    public partial class MainWindow : Window
    {
        [DllImport("BethOptimizer.Native.dll", CharSet = CharSet.Unicode)] private static extern int GetGpuName(StringBuilder buffer, int capacity);
        [DllImport("BethOptimizer.Native.dll")] private static extern int GetPrimaryMonitorHz();
        [DllImport("BethOptimizer.Native.dll")] private static extern int GetGpuVramGB();
        [DllImport("BethOptimizer.Native.dll", CharSet = CharSet.Unicode)] private static extern int GetCpuName(StringBuilder buffer, int capacity);
        [DllImport("BethOptimizer.Native.dll")] private static extern int GetPhysicalCores();
        [DllImport("BethOptimizer.Native.dll")] private static extern int GetLogicalCores();
        [DllImport("BethOptimizer.Native.dll")] private static extern int GetRamGB();

        private int TryGetHzWmi()
        {
            try
            {
                int best = 0;
                using var mos = new System.Management.ManagementObjectSearcher("select CurrentRefreshRate from Win32_VideoController");
                foreach (var o in mos.Get())
                {
                    if (int.TryParse(o["CurrentRefreshRate"]?.ToString(), out var hz))
                        best = Math.Max(best, hz);
                }
                return best;
            }
            catch { return 0; }
        }

        private int TryGetHzSmart()
        {
            try { return GetPrimaryMonitorHz(); }
            catch (System.DllNotFoundException) { return TryGetHzWmi(); }
            catch (System.EntryPointNotFoundException) { return TryGetHzWmi(); }
            catch { return TryGetHzWmi(); }
        }

        private HardwareDetector? _det;
        private HardwareDetector.HWInfo? _hw;
        private HardwareDetector.Recommendation? _rec;

        public MainWindow()
        {
            InitializeComponent();
            Title = "BethOptimizer v2.5 (Build 2503)";
        }

        private string DbPath
        {
            get
            {
                var baseDir = AppDomain.CurrentDomain.BaseDirectory;
                var p1 = System.IO.Path.Combine(baseDir, "hwdb.json");
                var p2 = System.IO.Path.Combine(baseDir, "data", "hwdb.json");
                return File.Exists(p1) ? p1 : p2;
            }
        }

        private void BtnScan_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _det = new HardwareDetector(DbPath);
                // Build HW info using native functions (no WMI)
                var sbCpu = new StringBuilder(256); GetCpuName(sbCpu, sbCpu.Capacity);
                var sbGpu = new StringBuilder(512); GetGpuName(sbGpu, sbGpu.Capacity);
                int hz  = TryGetHzSmart();
                int lg  = GetLogicalCores();
                int ph  = GetPhysicalCores();
                int ram = GetRamGB();
                int vram= GetGpuVramGB();
                _hw = new HardwareDetector.HWInfo(sbCpu.ToString(), lg, ph, ram, sbGpu.ToString(), vram, hz);
                _rec = _det.Recommend(_hw);

                var hw = _hw; var rec = _rec;
                TxtSummary.Text = $"{hw.CpuName} | {hw.GpuName} | RAM {hw.RamGB}GB | {hw.PrimaryHz}Hz";
                TxtPreset.Text = rec.Tier.ToUpperInvariant();
                TxtHz.Text = hw.PrimaryHz > 0 ? hw.PrimaryHz + " Hz" : "0 Hz";
                TxtSkyrim.Text = rec.SkyrimIni;
                TxtFo4.Text    = rec.Fallout4Ini;
                TxtSf.Text     = rec.StarfieldIni;
                TxtObr.Text    = rec.OblivionIni;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Errore scansione: " + ex.Message, "Errore", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnHz_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var hz = TryGetHzSmart();
                TxtHz.Text = hz > 0 ? $"{hz} Hz" : "0 Hz";
                if (hz > 0 && ChkCapToHz.IsChecked == true)
                {
                    ApplyFpsToPreview(hz);
                }
            }
            catch (Exception ex)
            {
                TxtHz.Text = "0 Hz";
            }
        }

        private void ApplyFpsToPreview(int fps)
        {
            // naive replace
            string repl(string s)
            {
                if (string.IsNullOrEmpty(s)) return s;
                s = System.Text.RegularExpressions.Regex.Replace(s, @"(fMaxFramerate\s*=\s*)\d+(\.0000)?", $"$1{fps}.0000", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                s = System.Text.RegularExpressions.Regex.Replace(s, @"(iFPSClamp\s*=\s*)\d+", $"$1{fps}", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                s = System.Text.RegularExpressions.Regex.Replace(s, @"(t\.MaxFPS\s*=\s*)\d+", $"$1{fps}", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                return s;
            }
            TxtSkyrim.Text = repl(TxtSkyrim.Text);
            TxtFo4.Text    = repl(TxtFo4.Text);
            TxtSf.Text     = repl(TxtSf.Text);
            TxtObr.Text    = repl(TxtObr.Text);
        }

        private void BtnWrite_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                WriteIniAll();
                MessageBox.Show("Scrittura completata (backup .bak creati se serviva).", "OK", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Errore scrittura: " + ex.Message, "Errore", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private static string MyDocs => Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

        
        
        private void WriteIniAll()
        {
            // Skyrim AE (Skyrim Special Edition folder)
            WriteWithBackup(System.IO.Path.Combine(MyDocs, "My Games", "Skyrim Special Edition", "SkyrimCustom.ini"), TxtSkyrim.Text);

            // Write to GOG variant only if present
            var gogDir = System.IO.Path.Combine(MyDocs, "My Games", "Skyrim Special Edition GOG");
            if (Directory.Exists(gogDir))
                WriteWithBackup(System.IO.Path.Combine(gogDir, "SkyrimCustom.ini"), TxtSkyrim.Text);

            // Fallout 4
            WriteWithBackup(System.IO.Path.Combine(MyDocs, "My Games", "Fallout4", "Fallout4Custom.ini"), TxtFo4.Text);

            // Starfield
            WriteWithBackup(System.IO.Path.Combine(MyDocs, "My Games", "Starfield", "StarfieldPrefs.ini"), TxtSf.Text);

            // Oblivion Remastered + fallback Oblivion
            WriteWithBackup(System.IO.Path.Combine(MyDocs, "My Games", "Oblivion Remastered", "Engine.ini"), TxtObr.Text);
            WriteWithBackup(System.IO.Path.Combine(MyDocs, "My Games", "Oblivion", "Engine.ini"), TxtObr.Text);
        }
private void WriteWithBackup(string path, string content)
        {
            var dir = Path.GetDirectoryName(path)!;
            Directory.CreateDirectory(dir);
            if (File.Exists(path))
            {
                var bak = path + "." + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".bak";
                File.Copy(path, bak, true);
            }
            File.WriteAllText(path, content ?? "");
        }

        // Downloads (SaveFileDialog)
        private void DlSkyrim_Click(object sender, RoutedEventArgs e) => SaveTo("SkyrimCustom.ini", TxtSkyrim.Text);
        private void DlFo4_Click(object sender, RoutedEventArgs e)    => SaveTo("Fallout4Custom.ini", TxtFo4.Text);
        private void DlSf_Click(object sender, RoutedEventArgs e)     => SaveTo("StarfieldPrefs.ini", TxtSf.Text);
        private void DlObr_Click(object sender, RoutedEventArgs e)    => SaveTo("Engine.ini", TxtObr.Text);

        private void SaveTo(string filename, string content)
        {
            var dlg = new SaveFileDialog { FileName = filename, Filter = "INI (*.ini)|*.ini|All files (*.*)|*.*" };
            if (dlg.ShowDialog() == true)
            {
                File.WriteAllText(dlg.FileName, content ?? "");
            }
        }

        private void BtnCredits_Click(object sender, RoutedEventArgs e)
        {
            var w = new CreditsWindow();
            w.Owner = this;
            w.ShowDialog();
        }
    }
}
