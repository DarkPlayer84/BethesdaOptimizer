
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using Microsoft.Win32;

internal static class Native
{
    [DllImport("BethOptimizer.Native.dll", CallingConvention = CallingConvention.Cdecl, CharSet=CharSet.Unicode)]
    public static extern int GetPrimaryMonitorHz();

    [DllImport("BethOptimizer.Native.dll", CallingConvention = CallingConvention.Cdecl, CharSet=CharSet.Unicode)]
    public static extern int GetAllMonitorsHzJSON(StringBuilder buffer, int bufferLen);

    [DllImport("BethOptimizer.Native.dll", CallingConvention = CallingConvention.Cdecl, CharSet=CharSet.Unicode)]
    public static extern int GetGpuName(StringBuilder buffer, int bufferLen);
}

public class Program
{
    static async Task Main(string[] args)
    {
        var prefix = "http://127.0.0.1:8765/";
        Console.WriteLine($"BethOptimizer.Helper listening on {prefix}");
        var listener = new HttpListener();
        listener.Prefixes.Add(prefix);
        listener.Start();

        while (true)
        {
            var ctx = await listener.GetContextAsync();
            _ = Task.Run(() => Handle(ctx));
        }
    }

    static void Cors(HttpListenerResponse resp)
    {
        resp.Headers["Access-Control-Allow-Origin"] = "*";
        resp.Headers["Access-Control-Allow-Methods"] = "GET,POST,OPTIONS";
        resp.Headers["Access-Control-Allow-Headers"] = "Content-Type";
    }

    static async Task Handle(HttpListenerContext ctx)
    {
        try
        {
            if (ctx.Request.HttpMethod == "OPTIONS")
            {
                Cors(ctx.Response);
                ctx.Response.StatusCode = 204;
                ctx.Response.Close();
                return;
            }

            Cors(ctx.Response);
            var path = ctx.Request.Url!.AbsolutePath;
            if (path == "/health")
            {
                await JsonOut(ctx, new { ok = true, name = "BethOptimizer.Helper", version = "1.0" });
            }
            else if (path == "/api/refresh")
            {
                await JsonOut(ctx, GetRefresh());
            }
            else if (path == "/api/gpu")
            {
                await JsonOut(ctx, GetGpu());
            }
            else if (path == "/api/write-ini" && ctx.Request.HttpMethod == "POST")
            {
                using var sr = new StreamReader(ctx.Request.InputStream, ctx.Request.ContentEncoding);
                var body = await sr.ReadToEndAsync();
                var req = JsonSerializer.Deserialize<WriteIniRequest>(body) ?? new();
                var result = WriteIni(req);
                await JsonOut(ctx, new { ok = true, result });
            }
            else if (path == "/api/steam-libraries")
            {
                await JsonOut(ctx, GetSteamLibraries());
            }
            else
            {
                ctx.Response.StatusCode = 404;
                await JsonOut(ctx, new { error = "Not Found" });
            }
        }
        catch (Exception ex)
        {
            ctx.Response.StatusCode = 500;
            await JsonOut(ctx, new { error = ex.Message, trace = ex.StackTrace });
        }
        finally
        {
            ctx.Response.Close();
        }
    }

    static async Task JsonOut(HttpListenerContext ctx, object obj)
    {
        ctx.Response.ContentType = "application/json; charset=utf-8";
        var json = JsonSerializer.Serialize(obj, new JsonSerializerOptions { WriteIndented = true });
        var bytes = Encoding.UTF8.GetBytes(json);
        await ctx.Response.OutputStream.WriteAsync(bytes, 0, bytes.Length);
    }

    static object GetRefresh()
    {
        try
        {
            var hz = Native.GetPrimaryMonitorHz();
            var sb = new StringBuilder(16384);
            int need = Native.GetAllMonitorsHzJSON(sb, sb.Capacity);
            string json = sb.ToString();
            return new { primaryHz = hz, monitors = TryParseJsonArray(json) };
        }
        catch
        {
            return new { primaryHz = 0, monitors = Array.Empty<object>() };
        }
    }

    static object GetGpu()
    {
        try
        {
            var sb = new StringBuilder(4096);
            int need = Native.GetGpuName(sb, sb.Capacity);
            string name = sb.ToString();
            return new { name, source = "DLL" };
        }
        catch
        {
            // Fallback to WMI
            try
            {
                string gpu = "";
                using var searcher = new System.Management.ManagementObjectSearcher("select Name from Win32_VideoController");
                foreach (var o in searcher.Get())
                {
                    gpu = o["Name"]?.ToString() ?? "";
                    if (!string.IsNullOrWhiteSpace(gpu)) break;
                }
                return new { name = string.IsNullOrWhiteSpace(gpu) ? "Unknown GPU" : gpu, source = "WMI" };
            }
            catch
            {
                return new { name = "Unknown GPU", source = "Unknown" };
            }
        }
    }

    public class WriteIniRequest
    {
        public string? Username { get; set; }
        public string? Skyrim { get; set; }
        public string? Fallout4 { get; set; }
        public string? Starfield { get; set; }
        public string? OblivionRemastered { get; set; }
    }

    static string EnsureCRLF(string? s) => (s ?? "").Replace("\r\n", "\n").Replace("\n", "\r\n");

    static object WriteIni(WriteIniRequest req)
    {
        string user = string.IsNullOrWhiteSpace(req.Username) ? Environment.UserName : req.Username.Trim();
        string docs = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
        string myGames = Path.Combine(docs, "My Games");

        var results = new System.Collections.Generic.List<object>();

        void WriteOne(string rel, string fileName, string? content)
        {
            if (string.IsNullOrWhiteSpace(content)) return;
            string dir = Path.Combine(myGames, rel);
            Directory.CreateDirectory(dir);
            string full = Path.Combine(dir, fileName);
            if (File.Exists(full))
            {
                File.Copy(full, full + ".bak", true);
            }
            File.WriteAllText(full, EnsureCRLF(content), new UTF8Encoding(false));
            results.Add(new { path = full, bytes = new FileInfo(full).Length });
        }

        WriteOne("Skyrim Special Edition", "SkyrimCustom.ini", req.Skyrim);
        WriteOne("Fallout4", "Fallout4Custom.ini", req.Fallout4);
        WriteOne("Starfield", "StarfieldPrefs.ini", req.Starfield);
        WriteOne(Path.Combine("Oblivion Remastered", "Saved", "Config", "Windows"), "Engine.ini", req.OblivionRemastered);

        return new { wrote = results };
    }

    static object GetSteamLibraries()
    {
        try
        {
            var list = new System.Collections.Generic.List<string>();
            string? steamPath = null;
            try
            {
                using var key = Registry.CurrentUser.OpenSubKey(@"Software\Valve\Steam");
                steamPath = key?.GetValue("SteamPath") as string;
            }
            catch { }

            if (!string.IsNullOrWhiteSpace(steamPath))
            {
                string libVdf = Path.Combine(steamPath, "steamapps", "libraryfolders.vdf");
                if (File.Exists(libVdf))
                {
                    string txt = File.ReadAllText(libVdf);
                    foreach (System.Text.RegularExpressions.Match m in System.Text.RegularExpressions.Regex.Matches(txt, "\"path\"\\s+\"([^\"]+)\""))
                    {
                        var p = m.Groups[1].Value.Replace("\\\\", "\\");
                        if (Directory.Exists(p)) list.Add(p);
                    }
                }
            }

            return new { libraries = list };
        }
        catch (Exception ex)
        {
            return new { error = ex.Message };
        }
    }

    static object[] TryParseJsonArray(string s)
    {
        try
        {
            var doc = System.Text.Json.JsonDocument.Parse(s);
            if (doc.RootElement.ValueKind == JsonValueKind.Array)
            {
                return doc.RootElement.EnumerateArray().Select(e => JsonElementToObj(e)).ToArray();
            }
        }
        catch { }
        return Array.Empty<object>();
    }

    static object JsonElementToObj(JsonElement e)
    {
        switch (e.ValueKind)
        {
            case JsonValueKind.Object:
                var dict = new System.Collections.Generic.Dictionary<string, object?>();
                foreach (var p in e.EnumerateObject()) dict[p.Name] = JsonElementToObj(p.Value);
                return dict;
            case JsonValueKind.Array:
                return e.EnumerateArray().Select(x => JsonElementToObj(x)).ToArray();
            case JsonValueKind.String: return e.GetString();
            case JsonValueKind.Number: return e.TryGetInt64(out var i) ? i : e.GetDouble();
            case JsonValueKind.True: return true;
            case JsonValueKind.False: return false;
            default: return null!;
        }
    }
}
