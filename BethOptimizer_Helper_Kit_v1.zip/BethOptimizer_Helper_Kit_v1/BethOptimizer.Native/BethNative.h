
#pragma once
#include <windows.h>

#ifdef BETHNATIVE_EXPORTS
#define BETHNATIVE_API __declspec(dllexport)
#else
#define BETHNATIVE_API __declspec(dllimport)
#endif

extern "C" {
// Returns current refresh rate (Hz) for the primary display, or 0 on failure.
BETHNATIVE_API int GetPrimaryMonitorHz();

// Writes a JSON array of monitors with fields: deviceName, deviceString, hz.
// Returns required wchar_t length (including null). If bufferLen is too small, return needed size.
BETHNATIVE_API int GetAllMonitorsHzJSON(wchar_t* buffer, int bufferLen);

// Writes a GPU adapter string (best effort). Returns required wchar_t length (including null).
BETHNATIVE_API int GetGpuName(wchar_t* buffer, int bufferLen);
}
