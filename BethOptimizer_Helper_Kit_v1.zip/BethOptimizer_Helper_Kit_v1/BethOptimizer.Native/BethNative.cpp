
#define WIN32_LEAN_AND_MEAN
#include "BethNative.h"
#include <windows.h>
#include <string>
#include <vector>
#include <sstream>

static int GetHzForDevice(const wchar_t* deviceName) {
    DEVMODEW dm = { 0 };
    dm.dmSize = sizeof(DEVMODEW);
    if (EnumDisplaySettingsW(deviceName, ENUM_CURRENT_SETTINGS, &dm)) {
        if (dm.dmDisplayFrequency >= 30 && dm.dmDisplayFrequency <= 1000) {
            return (int)dm.dmDisplayFrequency;
        }
    }
    return 0;
}

static std::wstring JsonEscape(const std::wstring& s) {
    std::wstringstream out;
    for (wchar_t c : s) {
        switch (c) {
        case L'\"': out << L"\\\""; break;
        case L'\\': out << L"\\\\"; break;
        case L'\b': out << L"\\b"; break;
        case L'\f': out << L"\\f"; break;
        case L'\n': out << L"\\n"; break;
        case L'\r': out << L"\\r"; break;
        case L'\t': out << L"\\t"; break;
        default:
            if (c < 32) out << L"\\u" << std::hex << (int)c;
            else out << c;
        }
    }
    return out.str();
}

extern "C" BETHNATIVE_API int GetPrimaryMonitorHz() {
    // Use DISPLAY1 as a simple heuristic for primary
    int hz = GetHzForDevice(L"DISPLAY");
    if (hz == 0) hz = GetHzForDevice(L"\\\\.\\DISPLAY1");
    if (hz == 0) {
        // fallback attempt: NULL device name
        DEVMODEW dm = { 0 };
        dm.dmSize = sizeof(DEVMODEW);
        if (EnumDisplaySettingsW(NULL, ENUM_CURRENT_SETTINGS, &dm)) {
            if (dm.dmDisplayFrequency >= 30 && dm.dmDisplayFrequency <= 1000) {
                hz = (int)dm.dmDisplayFrequency;
            }
        }
    }
    return hz;
}

extern "C" BETHNATIVE_API int GetAllMonitorsHzJSON(wchar_t* buffer, int bufferLen) {
    std::vector<std::wstring> entries;
    DISPLAY_DEVICEW dd;
    ZeroMemory(&dd, sizeof(dd));
    dd.cb = sizeof(dd);

    for (DWORD i = 0; EnumDisplayDevicesW(NULL, i, &dd, 0); ++i) {
        if (dd.StateFlags & DISPLAY_DEVICE_ATTACHED_TO_DESKTOP) {
            int hz = GetHzForDevice(dd.DeviceName);
            std::wstringstream ss;
            ss << L"{\"deviceName\":\"" << JsonEscape(dd.DeviceName) << L"\","
               << L"\"deviceString\":\"" << JsonEscape(dd.DeviceString) << L"\","
               << L"\"hz\":" << hz << L"}";
            entries.push_back(ss.str());
        }
        ZeroMemory(&dd, sizeof(dd));
        dd.cb = sizeof(dd);
    }

    std::wstringstream json;
    json << L"[";
    for (size_t k = 0; k < entries.size(); ++k) {
        if (k) json << L",";
        json << entries[k];
    }
    json << L"]";

    const std::wstring s = json.str();
    int need = (int)s.size() + 1;
    if (!buffer || bufferLen <= 0) return need;
    int toCopy = (bufferLen - 1 < need - 1) ? bufferLen - 1 : need - 1;
    wcsncpy_s(buffer, bufferLen, s.c_str(), toCopy);
    buffer[toCopy] = L'\0';
    return need;
}

extern "C" BETHNATIVE_API int GetGpuName(wchar_t* buffer, int bufferLen) {
    // Best-effort: use primary display device string
    DISPLAY_DEVICEW dd;
    ZeroMemory(&dd, sizeof(dd)); dd.cb = sizeof(dd);
    std::wstring name = L"";
    for (DWORD i = 0; EnumDisplayDevicesW(NULL, i, &dd, 0); ++i) {
        if (dd.StateFlags & DISPLAY_DEVICE_PRIMARY_DEVICE) {
            name = dd.DeviceString;
            break;
        }
        ZeroMemory(&dd, sizeof(dd)); dd.cb = sizeof(dd);
    }
    if (name.empty()) name = L"Unknown GPU";

    int need = (int)name.size() + 1;
    if (!buffer || bufferLen <= 0) return need;
    int toCopy = (bufferLen - 1 < need - 1) ? bufferLen - 1 : need - 1;
    wcsncpy_s(buffer, bufferLen, name.c_str(), toCopy);
    buffer[toCopy] = L'\0';
    return need;
}
