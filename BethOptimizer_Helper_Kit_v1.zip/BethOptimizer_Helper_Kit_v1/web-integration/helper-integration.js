
// Simple helper integration. Requires BethOptimizer.Helper running locally.
// Usage:
//   await boHelper.available();
//   const hz = await boHelper.getRefresh();
//   await boHelper.writeIni({ username, skyrim, fallout4, starfield, oblivionRemastered });
const boHelper = (()=>{
  const host = "http://127.0.0.1:8765";
  async function ping(){
    try{
      const r = await fetch(host + "/health", { method:"GET" });
      return r.ok;
    }catch{ return false; }
  }
  async function getRefresh(){
    const r = await fetch(host + "/api/refresh");
    return await r.json();
  }
  async function getGpu(){
    const r = await fetch(host + "/api/gpu");
    return await r.json();
  }
  async function writeIni({ username, skyrim, fallout4, starfield, oblivionRemastered }){
    const r = await fetch(host + "/api/write-ini", {
      method:"POST",
      headers:{ "Content-Type":"application/json" },
      body: JSON.stringify({
        Username: username || null,
        Skyrim: skyrim || "",
        Fallout4: fallout4 || "",
        Starfield: starfield || "",
        OblivionRemastered: oblivionRemastered || ""
      })
    });
    return await r.json();
  }
  async function steamLibraries(){
    const r = await fetch(host + "/api/steam-libraries");
    return await r.json();
  }
  return { available: ping, getRefresh, getGpu, writeIni, steamLibraries };
})();
export default boHelper;
