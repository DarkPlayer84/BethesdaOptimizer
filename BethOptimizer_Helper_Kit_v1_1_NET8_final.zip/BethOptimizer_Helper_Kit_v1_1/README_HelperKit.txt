# BethOptimizer Helper Kit (v1.1, .NET 8/9)

Aggiunge funzioni native all'app:
- Hz monitor e GPU via DLL C++.
- Server ASP.NET Core Minimal API su http://127.0.0.1:8765/
- Scrittura INI diretta in Documents\My Games (backup .bak, CRLF).

Progetti (Visual Studio 2022)
- BethOptimizer.Native — C++ DLL
- BethOptimizer.Helper — ASP.NET Core (.NET 8 LTS, 9 opzionale)

Build
- Apri BethOptimizer.sln e compila Release (x64 + net8.0-windows), oppure esegui:
  scripts\build.bat

Run
- scripts\run-helper.bat
- API: /health, /api/refresh, /api/gpu, /api/write-ini (POST), /api/steam-libraries
