using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.Win32;

internal static class Native
{
    [DllImport("BethOptimizer.Native.dll", CallingConvention = CallingConvention.Cdecl, CharSet=CharSet.Unicode)]
    public static extern int GetPrimaryMonitorHz();

    [DllImport("BethOptimizer.Native.dll", CallingConvention = CallingConvention.Cdecl, CharSet=CharSet.Unicode)]
    public static extern int GetAllMonitorsHzJSON(StringBuilder buffer, int bufferLen);

    [DllImport("BethOptimizer.Native.dll", CallingConvention = CallingConvention.Cdecl, CharSet=CharSet.Unicode)]
    public static extern int GetGpuName(StringBuilder buffer, int bufferLen);
}

var builder = WebApplication.CreateBuilder(args);
builder.WebHost.UseUrls("http://127.0.0.1:8765");
builder.Services.AddCors(o => o.AddDefaultPolicy(p => p.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod()));

var app = builder.Build();
app.UseCors();

app.MapGet("/health", () => Results.Json(new {
    ok = true,
    name = "BethOptimizer.Helper",
    version = "1.1",
    tfm = System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription
}));

app.MapGet("/api/refresh", () => Results.Json(GetRefresh()));
app.MapGet("/api/gpu", () => Results.Json(GetGpu()));
app.MapPost("/api/write-ini", async (HttpContext ctx) => {
    var req = await JsonSerializer.DeserializeAsync<WriteIniRequest>(ctx.Request.Body) ?? new();
    return Results.Json(new { ok = true, result = WriteIni(req) });
});
app.MapGet("/api/steam-libraries", () => Results.Json(GetSteamLibraries()));

app.Run();

static object GetRefresh()
{
    try
    {
        var hz = Native.GetPrimaryMonitorHz();
        var sb = new StringBuilder(16384);
        int need = Native.GetAllMonitorsHzJSON(sb, sb.Capacity);
        string json = sb.ToString();
        return new { primaryHz = hz, monitors = TryParseJsonArray(json) };
    }
    catch
    {
        return new { primaryHz = 0, monitors = Array.Empty<object>() };
    }
}

static object GetGpu()
{
    try
    {
        var sb = new StringBuilder(4096);
        int need = Native.GetGpuName(sb, sb.Capacity);
        string name = sb.ToString();
        return new { name, source = "DLL" };
    }
    catch
    {
        try
        {
            string gpu = "";
            using var searcher = new System.Management.ManagementObjectSearcher("select Name from Win32_VideoController");
            foreach (var o in searcher.Get())
            {
                gpu = o["Name"]?.ToString() ?? "";
                if (!string.IsNullOrWhiteSpace(gpu)) break;
            }
            return new { name = string.IsNullOrWhiteSpace(gpu) ? "Unknown GPU" : gpu, source = "WMI" };
        }
        catch
        {
            return new { name = "Unknown GPU", source = "Unknown" };
        }
    }
}

public class WriteIniRequest
{
    public string? Username { get; set; }
    public string? Skyrim { get; set; }
    public string? Fallout4 { get; set; }
    public string? Starfield { get; set; }
    public string? OblivionRemastered { get; set; }
}

static string EnsureCRLF(string? s) => (s ?? "").Replace("\r\n", "\n").Replace("\n", "\r\n");

static object WriteIni(WriteIniRequest req)
{
    string user = string.IsNullOrWhiteSpace(req.Username) ? Environment.UserName : req.Username.Trim();
    string docs = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
    string myGames = Path.Combine(docs, "My Games");

    var results = new List<object>();

    void WriteOne(string rel, string fileName, string? content)
    {
        if (string.IsNullOrWhiteSpace(content)) return;
        string dir = Path.Combine(myGames, rel);
        Directory.CreateDirectory(dir);
        string full = Path.Combine(dir, fileName);
        if (File.Exists(full))
        {
            File.Copy(full, full + ".bak", true);
        }
        File.WriteAllText(full, EnsureCRLF(content), new UTF8Encoding(false));
        results.Add(new { path = full, bytes = new FileInfo(full).Length });
    }

    WriteOne("Skyrim Special Edition", "SkyrimCustom.ini", req.Skyrim);
    WriteOne("Fallout4", "Fallout4Custom.ini", req.Fallout4);
    WriteOne("Starfield", "StarfieldPrefs.ini", req.Starfield);
    WriteOne(Path.Combine("Oblivion Remastered", "Saved", "Config", "Windows"), "Engine.ini", req.OblivionRemastered);

    return new { wrote = results };
}

static object GetSteamLibraries()
{
    try
    {
        var list = new List<string>();
        string? steamPath = null;
        try
        {
            using var key = Registry.CurrentUser.OpenSubKey(@"Software\Valve\Steam");
            steamPath = key?.GetValue("SteamPath") as string;
        }
        catch { }

        if (!string.IsNullOrWhiteSpace(steamPath))
        {
            string libVdf = Path.Combine(steamPath, "steamapps", "libraryfolders.vdf");
            if (File.Exists(libVdf))
            {
                string txt = File.ReadAllText(libVdf);
                foreach (Match m in Regex.Matches(txt, "\"path\"\\s+\"([^\"]+)\""))
                {
                    var p = m.Groups[1].Value.replace("\\\\", "\\");
                    if (Directory.Exists(p)) list.Add(p);
                }
            }
        }

        return new { libraries = list };
    }
    catch (Exception ex)
    {
        return new { error = ex.Message };
    }
}

static object[] TryParseJsonArray(string s)
{
    try
    {
        var doc = JsonDocument.Parse(s);
        if (doc.RootElement.ValueKind == JsonValueKind.Array)
        {
            return doc.RootElement.EnumerateArray().Select(e => JsonElementToObj(e)).ToArray();
        }
    }
    catch { }
    return Array.Empty<object>();
}

static object JsonElementToObj(JsonElement e)
{
    switch (e.ValueKind)
    {
        case JsonValueKind.Object:
            var dict = new Dictionary<string, object?>();
            foreach (var p in e.EnumerateObject()) dict[p.Name] = JsonElementToObj(p.Value);
            return dict;
        case JsonValueKind.Array:
            return e.EnumerateArray().Select(x => JsonElementToObj(x)).ToArray();
        case JsonValueKind.String: return e.GetString()!;
        case JsonValueKind.Number: return e.TryGetInt64(out var i) ? i : e.GetDouble();
        case JsonValueKind.True: return true;
        case JsonValueKind.False: return false;
        default: return null!;
    }
}
