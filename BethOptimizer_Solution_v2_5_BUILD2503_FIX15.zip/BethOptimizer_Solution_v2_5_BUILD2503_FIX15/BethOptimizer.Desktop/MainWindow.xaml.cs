using Microsoft.Web.WebView2.Core;
using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using System.Windows;

namespace BethOptimizer.Desktop
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Loaded;
        }

        [DllImport("BethOptimizer.Native.dll", EntryPoint="GetPrimaryMonitorHz", ExactSpelling=true, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        public static extern int GetPrimaryMonitorHz();

        [DllImport("BethOptimizer.Native.dll", EntryPoint="GetAllMonitorsHzJSON", ExactSpelling=true, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        public static extern int GetAllMonitorsHzJSON(StringBuilder buffer, int bufferLen);

        [DllImport("BethOptimizer.Native.dll", EntryPoint="GetGpuName", ExactSpelling=true, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        public static extern int GetGpuName(StringBuilder buffer, int bufferLen);

        private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            await web.EnsureCoreWebView2Async();
            string webRoot = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "webapp");
            web.CoreWebView2.SetVirtualHostNameToFolderMapping("app.local", webRoot, CoreWebView2HostResourceAccessKind.Allow);
            web.CoreWebView2.WebMessageReceived += CoreWebView2_WebMessageReceived;

            string bridgeJs = await File.ReadAllTextAsync(Path.Combine(webRoot, "bridge.js"));
            await web.CoreWebView2.AddScriptToExecuteOnDocumentCreatedAsync(bridgeJs);

            web.Source = new Uri("https://app.local/index.html");
        }

        private void CoreWebView2_WebMessageReceived(object? sender, CoreWebView2WebMessageReceivedEventArgs e)
        {
            try
            {
                var json = e.WebMessageAsJson;
                var req = JsonSerializer.Deserialize<Req>(json) ?? new Req();
                switch (req.cmd)
                {
                    case "getRefresh":
                        {
                            var sb = new StringBuilder(16384);
                            int hz = 0;
                            try { hz = GetPrimaryMonitorHz(); } catch { }
                            string monitors = "[]";
                            try
                            {
                                int need = GetAllMonitorsHzJSON(sb, sb.Capacity);
                                monitors = sb.ToString();
                            }
                            catch { }
                            Respond(req.id, new { primaryHz = hz, monitors = JsonSerializer.Deserialize<object>(monitors) });
                            break;
                        }
                    case "getGpu":
                        {
                            var sb = new StringBuilder(4096);
                            string name = "Unknown GPU";
                            try
                            {
                                int need = GetGpuName(sb, sb.Capacity);
                                name = sb.ToString();
                            }
                            catch { }
                            Respond(req.id, new { name, source = "DLL" });
                            break;
                        }
                    case "writeIni":
                        {
                            var p = req.payload ?? new();
                            var result = WriteIni(p);
                            Respond(req.id, new { ok = true, result });
                            break;
                        }
                    
                    case "scanHardware":
                        {
                            Func<int> getHz = () => { try { return GetPrimaryMonitorHz(); } catch { return 0; } };
                            Func<string> getGpu = () => {
                                try {
                                    var sb = new System.Text.StringBuilder(2048);
                                    int need = GetGpuName(sb, sb.Capacity);
                                    return sb.ToString();
                                } catch { return "Unknown GPU"; }
                            };
                            var dbPath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "hwdb.json");
                            if (!File.Exists(dbPath))
                                dbPath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "data", "hwdb.json");

                            var det = new HardwareDetector(dbPath);
                            var hw = HardwareDetector.Scan(getHz, getGpu);
                            var rec = det.Recommend(hw);
                            Respond(req.id, new { hw, rec });
                            break;
                        }

                    default:
                        Respond(req.id, new { error = "Unknown cmd" });
                        break;
                }
            }
            catch (Exception ex)
            {
                Respond(Guid.NewGuid().ToString(), new { error = ex.Message });
            }
        }

        private void Respond(string id, object data)
        {
            var resp = JsonSerializer.Serialize(new { id, data });
            web.CoreWebView2.PostWebMessageAsString(resp);
        }

        public record Req(string id = "", string cmd = "", Payload? payload = null);
        public record Payload(string? username = null, string? skyrim = null, string? fallout4 = null, string? starfield = null, string? oblivionRemastered = null);

        private static string EnsureCRLF(string? s) => (s ?? "").Replace("\r\n", "\n").Replace("\n", "\r\n");

        private object WriteIni(Payload req)
        {
            string docs = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            string myGames = Path.Combine(docs, "My Games");
            var results = new System.Collections.Generic.List<object>();

            void WriteOne(string rel, string fileName, string? content)
            {
                if (string.IsNullOrWhiteSpace(content)) return;
                string dir = Path.Combine(myGames, rel);
                Directory.CreateDirectory(dir);
                string full = Path.Combine(dir, fileName);
                if (File.Exists(full)) File.Copy(full, full + ".bak", true);
                File.WriteAllText(full, EnsureCRLF(content), new UTF8Encoding(false));
                results.Add(new { path = full, bytes = new FileInfo(full).Length });
            }

            WriteOne("Skyrim Special Edition", "SkyrimCustom.ini", req.skyrim);
            WriteOne("Fallout4", "Fallout4Custom.ini", req.fallout4);
            WriteOne("Starfield", "StarfieldPrefs.ini", req.starfield);
            WriteOne(Path.Combine("Oblivion Remastered", "Saved", "Config", "Windows"), "Engine.ini", req.oblivionRemastered);

            return new { wrote = results };
        }

        private async void web_NavigationCompleted(object? sender, CoreWebView2NavigationCompletedEventArgs e)
        {
            string inject = @"
(function(){
    const css = `.bo-native-float{position:fixed;right:12px;bottom:12px;z-index:9999;background:rgba(20,24,36,.9);border:1px solid rgba(255,255,255,.1);padding:.6rem .7rem;border-radius:.7rem;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;color:#e6ecff}
    .bo-native-float button{margin:.2rem .2rem 0 0;padding:.35rem .6rem;border-radius:.5rem;border:1px solid rgba(255,255,255,.15);background:rgba(255,255,255,.06);color:inherit;cursor:pointer}`;
    const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
    const box = document.createElement('div'); box.className='bo-native-float'; box.innerHTML='<div style=""font-weight:600;margin-bottom:.25rem"">Native bridge</div>';
    const b1 = document.createElement('button'); b1.textContent='Rileva Hz (native)';
    const b2 = document.createElement('button'); b2.textContent='Scrivi INI (native)';
    const b3 = document.createElement('button'); b3.textContent='Rileva HW (db)';
    box.appendChild(b1); box.appendChild(b3); box.appendChild(b2); document.body.appendChild(box);

    function setText(id, t){ const el=document.getElementById(id); if(el) el.textContent=t; }
    function fillIniFromHz(hz){
        if (document.getElementById('bo-hzOut')) document.getElementById('bo-hzOut').textContent = hz + ' Hz';
        if (hz){
            setText('bo-skyrim',['[Display]','iPresentInterval=0',`fMaxFramerate=${hz}.0000`].join('\n'));
            setText('bo-fo4',   ['[Display]','iPresentInterval=0','[General]',`iFPSClamp=${hz}`].join('\n'));
            setText('bo-sf',    ['[Display]','bEnableVsync=0'].join('\n'));
            setText('bo-obr',   ['[SystemSettings]',`t.MaxFPS=${hz}`,'r.VSync=0'].join('\n'));
        }
    }

    b1.onclick = async()=>{
        const r = await window.boBridge.request('getRefresh', null);
        const hz = r?.primaryHz||0;
        fillIniFromHz(hz);
        console.log('Monitors', r?.monitors);
    };

    b3.onclick = async()=>{
        const res = await window.boBridge.request('scanHardware', null);
        console.log('HW scan', res);
        const hw = res?.hw||{}; const rec = res?.rec||{};
        // show somewhere if elements exist
        setText('bo-hwSummary', `${hw.CpuName||''} | ${hw.GpuName||''} | RAM ${hw.RamGB||0}GB | ${hw.PrimaryHz||0}Hz`);
        // apply recommendations if textareas exist
        if (rec){
            setText('bo-skyrim', rec.SkyrimIni||'');
            setText('bo-fo4',    rec.Fallout4Ini||'');
            setText('bo-sf',     rec.StarfieldIni||'');
            setText('bo-obr',    rec.OblivionIni||'');
        }
        // try to set ""Performance Profile"" if a select exists
        const selects = Array.from(document.querySelectorAll('select'));
        const perfSel = selects.find(s => /profile/i.test(s.id||'') || /performance/i.test((s.closest('label')?.textContent||'')));
        if (perfSel && rec?.Tier){
            const opt = Array.from(perfSel.options).find(o => (o.textContent||'').toLowerCase().includes(rec.Tier));
            if (opt) { perfSel.value = opt.value; perfSel.dispatchEvent(new Event('change')); }
        }
        // update fps if slider exists
        const fpsInputs = Array.from(document.querySelectorAll('input[type=range],input[type=number]')).filter(i=>/fps|frame/i.test(i.id||i.name||''));
        fpsInputs.forEach(i=>{ i.value = rec.FpsCap||60; i.dispatchEvent(new Event('input')); i.dispatchEvent(new Event('change')); });
    };

    b2.onclick = async()=>{
        const payload = {
            username: document.getElementById('bo-username')?.value?.trim() || null,
            skyrim: document.getElementById('bo-skyrim')?.textContent || '',
            fallout4: document.getElementById('bo-fo4')?.textContent || '',
            starfield: document.getElementById('bo-sf')?.textContent || '',
            oblivionRemastered: document.getElementById('bo-obr')?.textContent || ''
        };
        const r = await window.boBridge.request('writeIni', payload);
        alert('Scrittura completata (vedi Console per dettagli).');
        console.log('writeIni result', r);
    };
})();
";
            await web.ExecuteScriptAsync(inject);
        }
    }
}