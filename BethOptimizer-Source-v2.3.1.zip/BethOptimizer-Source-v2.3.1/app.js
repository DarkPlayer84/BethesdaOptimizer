import { i18n, setLanguage, applyI18n } from './modules/i18n.js';
import { loadState, saveState, setMode, getMode, setLanguageState } from './modules/state.js';
import { initIniOptimizer } from './modules/iniOptimizer.js';
import { initDiagnostics } from './modules/diagnostics.js';
import { initDownloads } from './modules/downloads.js';
import { initDisplay } from './modules/displayRefresh.js';

const $=(q)=>document.querySelector(q), $$=(q)=>document.querySelectorAll(q);
const modePill=$('#modePill'), overlay=$('#overlay'), overlayClose=$('#overlayClose'), eulaTimer=$('#eulaTimer');
const langIT=$('#langIT'), langEN=$('#langEN');
const btnDemoTool=$('#btnDemoTool'), btnFullTool=$('#btnFullTool'), fullHint=$('#fullHint');
const menuButtons=$$('.menu-item'), views=$$('.view');

function updatePill(mode){ const isFull=mode==='full'; modePill.textContent=isFull?i18n('ui.modeFull'):i18n('ui.modeDemo'); modePill.style.background=isFull?'var(--success)':'var(--danger)'; }
function switchView(id){ views.forEach(v=>v.classList.toggle('active', v.id===id)); menuButtons.forEach(b=>b.classList.toggle('active','view-'+b.dataset.view===id)); }

function initUI(){
  menuButtons.forEach(btn=>btn.addEventListener('click',()=>switchView('view-'+btn.dataset.view)));
  btnDemoTool.addEventListener('click',()=>log('[DEMO] '+i18n('logs.demoRun')));
  btnFullTool.addEventListener('click',()=>log('[FULL] '+i18n('logs.fullRun')));

  const setLang=(lang)=>{ setLanguageState(lang); setLanguage(lang); applyI18n(); updatePill(getMode()); };
  langIT.addEventListener('click',()=>setLang('it')); langEN.addEventListener('click',()=>setLang('en'));

  // Overlay show + auto-close in 30s, closable with X and Esc
  overlay.style.display='flex';
  let left = 30;
  function fmt(s){ const m=String(Math.floor(s/60)).padStart(2,'0'); const ss=String(s%60).padStart(2,'0'); return m+':'+ss; }
  function closeOverlay(){ clearInterval(tick); overlay.style.display='none'; }
  eulaTimer.textContent = 'Si chiude automaticamente tra ' + fmt(left);
  const tick = setInterval(()=>{ left--; if(left<=0){ closeOverlay(); } else { eulaTimer.textContent='Si chiude automaticamente tra ' + fmt(left); } }, 1000);
  overlayClose.addEventListener('click', closeOverlay);
  document.addEventListener('keydown', (e)=>{ if(e.key==='Escape') closeOverlay(); }, { once:true });
}

function log(t){ const box=$('#logBox'), dt=new Date().toLocaleString(); box.textContent+=`[${dt}] ${t}\n`; box.scrollTop=box.scrollHeight; }

function boot(){
  const st=loadState();
  if(!st.language) setLanguageState('it');
  setLanguage(loadState().language||'it'); applyI18n();
  setMode('full'); updatePill(getMode());
  initUI(); initIniOptimizer(); initDiagnostics(); initDownloads(); initDisplay();
}
document.addEventListener('DOMContentLoaded', boot);
