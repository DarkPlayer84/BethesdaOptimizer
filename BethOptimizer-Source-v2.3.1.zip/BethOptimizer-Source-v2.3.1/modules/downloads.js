let items=[]; const KEY='bo_downloads';
function persist(){ localStorage.setItem(KEY, JSON.stringify(items)); }
function restore(){ try{ items=JSON.parse(localStorage.getItem(KEY)||'[]'); if(!Array.isArray(items)) items=[]; }catch{ items=[]; } }
function render(){ const ul=document.getElementById('downloadList'); const exportZipBtn=document.getElementById('btnExportZip'); ul.innerHTML=''; exportZipBtn.disabled=items.length===0;
  for(const it of items){ const li=document.createElement('li'); li.className='card'; const a=document.createElement('a'); a.href=URL.createObjectURL(new Blob([it.content],{type:'text/plain'}));
    a.download=it.name; a.textContent='Salva: '+it.name; const meta=document.createElement('div'); meta.className='hint'; meta.textContent=new Date(it.ts).toLocaleString();
    const del=document.createElement('button'); del.className='ghost'; del.textContent='Rimuovi'; del.addEventListener('click',()=>{ URL.revokeObjectURL(a.href); items=items.filter(x=>x.ts!==it.ts); persist(); render(); });
    li.appendChild(a); li.appendChild(meta); li.appendChild(del); ul.appendChild(li); } }
export function addDownload(name, content){ items.push({name, content, ts: Date.now()}); persist(); render(); }
export function initDownloads(){ restore(); render(); document.getElementById('btnClearDownloads').addEventListener('click',()=>{ items=[]; persist(); render(); });
  document.getElementById('btnExportZip').addEventListener('click', async()=>{ if(items.length===0) return; const zipBlob=await createZip(items); const a=document.createElement('a'); a.href=URL.createObjectURL(zipBlob); a.download='BethOptimizer_Downloads.zip'; a.click(); URL.revokeObjectURL(a.href); }); }
async function createZip(files){ function strToUint8(str){ return new TextEncoder().encode(str); } function crc32(buf){ let c=~0>>>0; for(let i=0;i<buf.length;i++){ c^=buf[i]; for(let k=0;k<8;k++){ c=(c>>>1)^(0xEDB88320 & (-(c&1))); } } return (~c)>>>0; }
  const chunks=[], central=[]; let offset=0; for(const f of files){ const name=f.name; const data=strToUint8(f.content); const crc=crc32(data);
    const h=new DataView(new ArrayBuffer(30)); h.setUint32(0,0x04034b50,true); h.setUint16(4,20,true); h.setUint16(6,0,true); h.setUint16(8,0,true); h.setUint16(10,0,true); h.setUint16(12,0,true);
    h.setUint32(14,crc,true); h.setUint32(18,data.length,true); h.setUint32(22,data.length,true); h.setUint16(26,name.length,true); h.setUint16(28,0,true); chunks.push(h, strToUint8(name), data);
    const c=new DataView(new ArrayBuffer(46)); c.setUint32(0,0x02014b50,true); c.setUint16(4,20,true); c.setUint16(6,20,true); c.setUint16(8,0,true); c.setUint16(10,0,true); c.setUint16(12,0,true);
    c.setUint32(14,crc,true); c.setUint32(18,data.length,true); c.setUint32(22,data.length,true); c.setUint16(26,name.length,true); c.setUint16(28,0,true); c.setUint16(30,0,true); c.setUint16(32,0,true); c.setUint16(34,0,true); c.setUint32(36,0,true); c.setUint32(40,offset,true);
    central.push(c, strToUint8(name)); offset += 30 + name.length + data.length; }
  const centralSize = central.reduce((a,b)=>a+((b.byteLength||b.length)),0); const centralOffset=offset; const end=new DataView(new ArrayBuffer(22));
  end.setUint32(0,0x06054b50,true); end.setUint16(4,0,true); end.setUint16(6,0,true); end.setUint16(8,files.length,true); end.setUint16(10,files.length,true); end.setUint32(12,centralSize,true); end.setUint32(16,centralOffset,true); end.setUint16(20,0,true);
  const size=offset+centralSize+22; const out=new Uint8Array(size); let p=0; for(const part of chunks){ const arr=part instanceof Uint8Array?part:new Uint8Array(part.buffer); out.set(arr,p); p+=arr.length; }
  for(const part of central){ const arr=part instanceof Uint8Array?part:new Uint8Array(part.buffer); out.set(arr,p); p+=arr.length; } out.set(new Uint8Array(end.buffer), p); return new Blob([out],{type:'application/zip'}); }
