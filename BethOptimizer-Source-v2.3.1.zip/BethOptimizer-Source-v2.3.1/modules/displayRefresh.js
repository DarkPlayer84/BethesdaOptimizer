import { addDownload } from './downloads.js';
export function initDisplay(){
  const $=(q)=>document.querySelector(q);
  const btnDetect=$('#btnDetectHz'); const hzOut=$('#hzOut');
  const preSkyrim=$('#skyrimIni'), dlSkyrim=$('#dlSkyrim'), addSkyrim=$('#addSkyrim');
  const preFo4=$('#fo4Ini'), dlFo4=$('#dlFo4'), addFo4=$('#addFo4');
  const preSf=$('#sfPrefs'), dlSf=$('#dlSf'), addSf=$('#addSf');
  const preObr=$('#obRem'), dlObr=$('#dlObr'), addObr=$('#addObr');
  let hz=null;
  async function detectHz(durationMs=1500){ return new Promise((resolve)=>{ let frames=0; const start=performance.now(); function tick(t){ frames++; if(t-start>=durationMs){ const elapsed=t-start; resolve(Math.round((frames/elapsed)*1000)); return;} requestAnimationFrame(tick);} requestAnimationFrame(tick); }); }
  function nearestCommon(fps){ const common=[60,75,90,120,144,165,170,175,180,200,240,300,360]; let best=fps,diff=999; for(const v of common){ const d=Math.abs(fps-v); if(d<diff && d<=3){ best=v; diff=d; } } return best; }
  function skyrimIni(h){ return ['[Display]','iPresentInterval=0',`fMaxFramerate=${h}.0000`].join('\n'); }
  function fo4Ini(h){ return ['[Display]','iPresentInterval=0','[General]',`iFPSClamp=${h}`].join('\n'); }
  function starfieldPrefs(){ return ['[Display]','bEnableVsync=0'].join('\n'); }
  function obrEngineIni(h){ return ['[SystemSettings]',`t.MaxFPS=${h}`,'r.VSync=0'].join('\n'); }
  function updateOutputs(h){ preSkyrim.textContent=skyrimIni(h); preFo4.textContent=fo4Ini(h); preSf.textContent=starfieldPrefs(); preObr.textContent=obrEngineIni(h);
    [dlSkyrim,dlFo4,dlSf,dlObr].forEach(b=>b.disabled=false); [addSkyrim,addFo4,addSf,addObr].forEach(b=>b.disabled=false); }
  btnDetect.addEventListener('click', async()=>{ hzOut.textContent='...'; const raw=await detectHz(); const best=nearestCommon(raw); hz=best; hzOut.textContent=best+' Hz'; updateOutputs(best); });
  function download(name,text){ const blob=new Blob([text],{type:'text/plain'}); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=name; a.click(); URL.revokeObjectURL(a.href); }
  dlSkyrim.addEventListener('click',()=>{ if(hz==null) return; download('SkyrimCustom.ini', preSkyrim.textContent); });
  dlFo4.addEventListener('click',()=>{ if(hz==null) return; download('Fallout4Custom.ini', preFo4.textContent); });
  dlSf.addEventListener('click',()=>{ download('StarfieldPrefs.ini', preSf.textContent); });
  dlObr.addEventListener('click',()=>{ if(hz==null) return; download('Engine.ini', preObr.textContent); });
  addSkyrim.addEventListener('click',()=>{ if(hz==null) return; addDownload('SkyrimCustom.ini', preSkyrim.textContent); });
  addFo4.addEventListener('click',()=>{ if(hz==null) return; addDownload('Fallout4Custom.ini', preFo4.textContent); });
  addSf.addEventListener('click',()=>{ addDownload('StarfieldPrefs.ini', preSf.textContent); });
  addObr.addEventListener('click',()=>{ if(hz==null) return; addDownload('Engine.ini', preObr.textContent); });
}