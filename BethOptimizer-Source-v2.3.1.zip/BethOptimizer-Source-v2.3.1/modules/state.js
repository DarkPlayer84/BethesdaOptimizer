let cache=null;
export function loadState(){ if(cache) return cache; try{ cache=JSON.parse(localStorage.getItem('bo_state')||'{}'); }catch{ cache={}; } return cache; }
export function saveState(st){ cache=st; localStorage.setItem('bo_state', JSON.stringify(st)); }
export function setMode(mode){ const st=loadState(); st.mode=mode; saveState(st); }
export function getMode(){ const st=loadState(); return st.mode || 'full'; }
export function setLanguageState(lang){ const st=loadState(); st.language=lang; saveState(st); }
