const STRINGS = {
  it: {
    'ui.modeFull':'Modalità: COMPLETA','ui.modeDemo':'Modalità: DEMO',
    'menu.home':'Home','menu.display':'Display & Refresh','menu.ini':'Ottimizzatore INI','menu.presets':'Preset','menu.downloads':'Download','menu.diagnostics':'Diagnostica','menu.about':'Info',
    'home.title':'Benvenuto in BethOptimizer','home.desc':'Apri questo file <strong>index.html</strong> e usa l\'app — non serve installare nulla.','home.demoTool':'Strumento demo','home.fullTool':'Strumento completo','home.hint':'Le funzioni sono attive.',
    'ini.title':'Ottimizzatore INI','ini.input':'Input INI','ini.output':'Output INI ottimizzato','ini.optimize':'Ottimizza','ini.validate':'Valida','ini.copy':'Copia','ini.download':'Scarica INI','ini.import':'Importa file',
    'presets.title':'Preset','presets.save':'Salva preset','presets.export':'Esporta tutti','presets.import':'Importa',
    'downloads.title':'Area Download','downloads.desc':'Qui compariranno i file generati. Salvali dove vuoi.',
    'diag.title':'Diagnostica',
    'display.title':'Display & Refresh','display.note':'Rileva automaticamente gli Hz del monitor e genera i cap corretti per Skyrim AE, Fallout 4, Starfield e Oblivion Remastered.','display.detect':'Rileva Hz',
    'about.text':'Applicazione client-side. Tutto gira nel browser. Nessuna installazione.',
    'logs.demoRun':'Esempio di funzione demo eseguita.','logs.fullRun':'Funzione completa eseguita.'
  },
  en: {
    'ui.modeFull':'Mode: FULL','ui.modeDemo':'Mode: DEMO',
    'menu.home':'Home','menu.display':'Display & Refresh','menu.ini':'INI Optimizer','menu.presets':'Presets','menu.downloads':'Downloads','menu.diagnostics':'Diagnostics','menu.about':'About',
    'home.title':'Welcome to BethOptimizer','home.desc':'Open this <strong>index.html</strong> and use the app — no installation required.','home.demoTool':'Demo tool','home.fullTool':'Full tool','home.hint':'Features are active.',
    'ini.title':'INI Optimizer','ini.input':'INI Input','ini.output':'Optimized INI Output','ini.optimize':'Optimize','ini.validate':'Validate','ini.copy':'Copy','ini.download':'Download INI','ini.import':'Import file',
    'presets.title':'Presets','presets.save':'Save preset','presets.export':'Export all','presets.import':'Import',
    'downloads.title':'Download Area','downloads.desc':'Generated files will appear here. Save them wherever you want.',
    'diag.title':'Diagnostics',
    'display.title':'Display & Refresh','display.note':'Auto-detect monitor Hz and generate correct caps for Skyrim AE, Fallout 4, Starfield and Oblivion Remastered.','display.detect':'Detect Hz',
    'about.text':'Fully client-side app. Runs in your browser. No install.',
    'logs.demoRun':'Demo feature executed.','logs.fullRun':'Full feature executed.'
  }
};
let currentLang='it';
export function setLanguage(lang){ currentLang=(lang==='en')?'en':'it'; document.documentElement.lang=currentLang; }
export function i18n(key){ return (STRINGS[currentLang] && STRINGS[currentLang][key]) || key; }
export function applyI18n(){ document.querySelectorAll('[data-i18n]').forEach(el=>{ const k=el.getAttribute('data-i18n'); el.innerHTML=i18n(k); }); }
export { currentLang };
