import { addDownload } from './downloads.js';
export function initIniOptimizer(){
  const $=(q)=>document.querySelector(q);
  const input=$('#iniInput'), output=$('#iniOutput'), report=$('#iniReport');
  const btnOptimize=$('#btnOptimize'), btnValidate=$('#btnValidate'), btnCopy=$('#btnCopy'), btnDownload=$('#btnDownload'), fileInput=$('#iniFile');
  const btnAddDownload=$('#btnAddDownload');
  function optimize(text){ const lines=text.split(/\r?\n/); let current=null; const map=new Map();
    for(let raw of lines){ let ln=raw.trim(); if(!ln||ln.startsWith(';')||ln.startsWith('#')) continue; const sec=ln.match(/^\[(.+)\]$/); if(sec){ current=sec[1].trim(); if(!map.has(current)) map.set(current,new Map()); continue; }
      const kv=ln.match(/^([^=\s]+)\s*=\s*(.*)$/); if(kv&&current){ map.get(current).set(kv[1].trim(), kv[2].trim()); } }
    const out=[]; for(const [section,kvs] of map.entries()){ out.push(`[${section}]`); for(const [k,v] of kvs.entries()){ out.push(`${k}=${v}`); } } return out.join('\n'); }
  btnOptimize.addEventListener('click',()=>{ const res=optimize(input.value||''); output.value=res; report.innerHTML='Ottimizzato.'; });
  btnValidate.addEventListener('click',()=>{ const txt=(output.value||input.value||''); const issues=[]; const lines=txt.split(/\r?\n/); for(let i=0;i<lines.length;i++){ if(!lines[i].trim()) issues.push(`Linea ${i+1}: riga vuota non consentita.`); }
    report.innerHTML=issues.length?`<span style='color:#f7768e'>Errori:</span><br>${issues.map(x=>'- '+x).join('<br>')}`:'<span style='color:#9ece6a'>Valido secondo le regole.</span>'; });
  btnCopy.addEventListener('click',async()=>{ const txt=(output.value||'').trim(); if(!txt) return; await navigator.clipboard.writeText(txt); report.innerHTML='<span style="color:#9ece6a">Copiato negli appunti.</span>'; });
  btnDownload.addEventListener('click',()=>{ const name=prompt('Nome file (es. Optimized.ini):','Optimized.ini')||'Optimized.ini';
    const blob=new Blob([output.value],{type:'text/plain'}); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=name; a.click(); URL.revokeObjectURL(a.href); });
  btnAddDownload.addEventListener('click',()=>{ const name=prompt('Nome file per l\'Area Download:','Optimized.ini')||'Optimized.ini'; addDownload(name,(output.value||'')); });
  fileInput.addEventListener('change',async(e)=>{ const f=e.target.files[0]; if(!f) return; input.value=await f.text(); report.innerHTML='File caricato.'; });
}