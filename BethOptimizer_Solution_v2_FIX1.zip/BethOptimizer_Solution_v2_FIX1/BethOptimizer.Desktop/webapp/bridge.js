(function(){
  const inflight=new Map();
  function uuid(){return Math.random().toString(36).slice(2)+Date.now().toString(36);}
  window.boBridge={request:function(cmd,payload){return new Promise((res)=>{const id=uuid();inflight.set(id,res);chrome.webview.postMessage(JSON.stringify({id,cmd,payload}));});}};
  chrome.webview.addEventListener('message',ev=>{try{const m=JSON.parse(ev.data);const f=inflight.get(m.id);if(f){inflight.delete(m.id);f(m.data);}}catch(e){console.warn('bridge parse',e);}});
})();