#pragma once
#include <windows.h>

#ifdef BETHNATIVE_EXPORTS
#define BETHNATIVE_API __declspec(dllexport)
#else
#define BETHNATIVE_API __declspec(dllimport)
#endif

extern "C" {
BETHNATIVE_API int GetPrimaryMonitorHz();
BETHNATIVE_API int GetAllMonitorsHzJSON(wchar_t* buffer, int bufferLen);
BETHNATIVE_API int GetGpuName(wchar_t* buffer, int bufferLen);
}
