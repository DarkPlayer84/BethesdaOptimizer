using System.Diagnostics;
using System.Windows;

namespace BethOptimizer.Desktop
{
    public partial class CreditsWindow : Window
    {
        public CreditsWindow()
        {
            InitializeComponent();
        }

        private void Open(string url)
        {
            try
            {
                Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
            }
            catch { }
        }

        private void Ok_Click(object sender, RoutedEventArgs e) => this.Close();

        private void YouTube_Click(object sender, RoutedEventArgs e) => Open("https://www.youtube.com/@DarkPlayer84TvProductions");
        private void Twitter_Click(object sender, RoutedEventArgs e) => Open("https://twitter.com/oldgamerdarthy");
        private void Instagram_Click(object sender, RoutedEventArgs e) => Open("https://instagram.com/"); // placeholder, add if needed
        private void Twitch_Click(object sender, RoutedEventArgs e) => Open("https://twitch.tv/darkplayer84tv");
        private void TikTok_Click(object sender, RoutedEventArgs e) => Open("https://tiktok.com/@darkplayer84tv");
    }
}
