using System.Windows;

namespace BethOptimizer.Desktop
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
            AppDomain.CurrentDomain.UnhandledException += (s, ex) => ReportUnhandled("AppDomain", ex.ExceptionObject as Exception);
            this.DispatcherUnhandledException += (s, ex) => { ReportUnhandled("Dispatcher", ex.Exception); ex.Handled = true; };
        }

        private void ReportUnhandled(string source, Exception? ex)
        {
            try
            {
                string msg = (ex?.ToString() ?? "Unknown error");
                string dir = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "BethOptimizer", "logs");
                System.IO.Directory.CreateDirectory(dir);
                string path = System.IO.Path.Combine(dir, $"crash_{DateTime.Now:yyyyMMdd_HHmmss}.log");
                System.IO.File.WriteAllText(path, $"[{source}] {msg}");
                MessageBox.Show($"Errore non gestito ({source}).\nLog: {path}\n\n{ex?.Message}", "BethOptimizer", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch { /* swallow */ }
        }
    }
}
