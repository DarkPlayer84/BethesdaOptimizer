using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows;
using Microsoft.Win32;

namespace BethOptimizer.Desktop
{
    public partial class MainWindow : Window
    {
        [DllImport("BethOptimizer.Native.dll", CharSet = CharSet.Unicode)]
        private static extern int GetGpuName(StringBuilder buffer, int capacity);

        [DllImport("BethOptimizer.Native.dll")]
        private static extern int GetPrimaryMonitorHz();

        private HardwareDetector? _det;
        private HardwareDetector.HWInfo? _hw;
        private HardwareDetector.Recommendation? _rec;

        public MainWindow()
        {
            InitializeComponent();
            Title = "BethOptimizer v2.5 (Build 2503)";
        }

        private string DbPath
        {
            get
            {
                var baseDir = AppDomain.CurrentDomain.BaseDirectory;
                var p1 = System.IO.Path.Combine(baseDir, "hwdb.json");
                var p2 = System.IO.Path.Combine(baseDir, "data", "hwdb.json");
                return File.Exists(p1) ? p1 : p2;
            }
        }

        private void BtnScan_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _det = new HardwareDetector(DbPath);
                Func<int> getHz = () => { try { return GetPrimaryMonitorHz(); } catch { return 0; } };
                Func<string> getGpu = () => {
                    try { var sb = new StringBuilder(2048); GetGpuName(sb, sb.Capacity); return sb.ToString(); } catch { return "Unknown GPU"; }
                };
                _hw = HardwareDetector.Scan(getHz, getGpu);
                _rec = _det.Recommend(_hw);

                if (_hw is not null && _rec is not null)
                {
                    var hw = _hw; var rec = _rec;
                    TxtSummary.Text = $"{hw.CpuName} | {hw.GpuName} | RAM {hw.RamGB}GB | {hw.PrimaryHz}Hz";
                    TxtPreset.Text = rec.Tier.ToUpperInvariant();
                    if (hw.PrimaryHz > 0) TxtHz.Text = hw.PrimaryHz + " Hz";

                    TxtSkyrim.Text = rec.SkyrimIni;
                    TxtFo4.Text    = rec.Fallout4Ini;
                    TxtSf.Text     = rec.StarfieldIni;
                    TxtObr.Text    = rec.OblivionIni;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Errore scansione: " + ex.Message, "Errore", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnHz_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var hz = GetPrimaryMonitorHz();
                TxtHz.Text = hz > 0 ? $"{hz} Hz" : "";
                if (hz > 0 && ChkCapToHz.IsChecked == true)
                {
                    ApplyFpsToPreview(hz);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Errore lettura Hz: " + ex.Message, "Errore", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ApplyFpsToPreview(int fps)
        {
            // naive replace
            string repl(string s)
            {
                if (string.IsNullOrEmpty(s)) return s;
                s = System.Text.RegularExpressions.Regex.Replace(s, @"(fMaxFramerate\s*=\s*)\d+(\.0000)?", $"$1{fps}.0000", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                s = System.Text.RegularExpressions.Regex.Replace(s, @"(iFPSClamp\s*=\s*)\d+", $"$1{fps}", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                s = System.Text.RegularExpressions.Regex.Replace(s, @"(t\.MaxFPS\s*=\s*)\d+", $"$1{fps}", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                return s;
            }
            TxtSkyrim.Text = repl(TxtSkyrim.Text);
            TxtFo4.Text    = repl(TxtFo4.Text);
            TxtSf.Text     = repl(TxtSf.Text);
            TxtObr.Text    = repl(TxtObr.Text);
        }

        private void BtnWrite_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                WriteIniAll();
                MessageBox.Show("Scrittura completata (backup .bak creati se serviva).", "OK", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Errore scrittura: " + ex.Message, "Errore", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private static string MyDocs => Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

        
        private void WriteIniAll()
        {
            // Skyrim Anniversary Edition (path is the same of Special Edition)
            var seDir = System.IO.Path.Combine(MyDocs, "My Games", "Skyrim Special Edition");
            if (Directory.Exists(seDir))
                WriteWithBackup(System.IO.Path.Combine(seDir, "SkyrimCustom.ini"), TxtSkyrim.Text);

            // Skyrim Special Edition (GOG) - write only if folder exists
            var gogDir = System.IO.Path.Combine(MyDocs, "My Games", "Skyrim Special Edition GOG");
            if (Directory.Exists(gogDir))
                WriteWithBackup(System.IO.Path.Combine(gogDir, "SkyrimCustom.ini"), TxtSkyrim.Text);

            // Fallout 4
            var fo4Dir = System.IO.Path.Combine(MyDocs, "My Games", "Fallout4");
            if (Directory.Exists(fo4Dir))
                WriteWithBackup(System.IO.Path.Combine(fo4Dir, "Fallout4Custom.ini"), TxtFo4.Text);

            // Starfield
            var sfDir = System.IO.Path.Combine(MyDocs, "My Games", "Starfield");
            if (Directory.Exists(sfDir))
                WriteWithBackup(System.IO.Path.Combine(sfDir, "StarfieldPrefs.ini"), TxtSf.Text);

            // Oblivion Remastered
            var obrDir = System.IO.Path.Combine(MyDocs, "My Games", "Oblivion Remastered");
            if (Directory.Exists(obrDir))
                WriteWithBackup(System.IO.Path.Combine(obrDir, "Engine.ini"), TxtObr.Text);

            var obDir = System.IO.Path.Combine(MyDocs, "My Games", "Oblivion");
            if (Directory.Exists(obDir))
                WriteWithBackup(System.IO.Path.Combine(obDir, "Engine.ini"), TxtObr.Text);
        }
private void WriteWithBackup(string path, string content)
        {
            var dir = Path.GetDirectoryName(path)!;
            Directory.CreateDirectory(dir);
            if (File.Exists(path))
            {
                var bak = path + "." + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".bak";
                File.Copy(path, bak, true);
            }
            File.WriteAllText(path, content ?? "");
        }

        // Downloads (SaveFileDialog)
        private void DlSkyrim_Click(object sender, RoutedEventArgs e) => SaveTo("SkyrimCustom.ini", TxtSkyrim.Text);
        private void DlFo4_Click(object sender, RoutedEventArgs e)    => SaveTo("Fallout4Custom.ini", TxtFo4.Text);
        private void DlSf_Click(object sender, RoutedEventArgs e)     => SaveTo("StarfieldPrefs.ini", TxtSf.Text);
        private void DlObr_Click(object sender, RoutedEventArgs e)    => SaveTo("Engine.ini", TxtObr.Text);

        private void SaveTo(string filename, string content)
        {
            var dlg = new SaveFileDialog { FileName = filename, Filter = "INI (*.ini)|*.ini|All files (*.*)|*.*" };
            if (dlg.ShowDialog() == true)
            {
                File.WriteAllText(dlg.FileName, content ?? "");
            }
        }

        private void BtnCredits_Click(object sender, RoutedEventArgs e)
        {
            var w = new CreditsWindow();
            w.Owner = this;
            w.ShowDialog();
        }
    }
}
