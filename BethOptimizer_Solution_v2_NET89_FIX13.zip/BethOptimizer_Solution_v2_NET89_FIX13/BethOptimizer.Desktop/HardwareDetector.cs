
using System;
using System.IO;
using System.Linq;
using System.Management;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Collections.Generic;

namespace BethOptimizer.Desktop
{
    public class HardwareDetector
    {
        public record HWInfo(string CpuName, int LogicalCores, int PhysicalCores, int RamGB, string GpuName, int GpuVramGB, int PrimaryHz);
        public record Recommendation(string Tier, int FpsCap, string SkyrimIni, string Fallout4Ini, string StarfieldIni, string OblivionIni);

        private readonly JsonNode _db;

        public HardwareDetector(string dbPath)
        {
            var json = File.ReadAllText(dbPath);
            _db = JsonNode.Parse(json) ?? new JsonObject();
        }

        public static HWInfo Scan(Func<int> getPrimaryHz, Func<string> getGpuNameFallback)
        {
            // CPU via WMI
            string cpuName = "Unknown CPU";
            int logical = 0, physical = 0;
            try
            {
                using var mos = new ManagementObjectSearcher("select Name, NumberOfCores, NumberOfLogicalProcessors from Win32_Processor");
                foreach (var o in mos.Get())
                {
                    cpuName = (o["Name"]?.ToString() ?? cpuName).Trim();
                    if (int.TryParse(o["NumberOfCores"]?.ToString(), out var c)) physical = Math.Max(physical, c);
                    if (int.TryParse(o["NumberOfLogicalProcessors"]?.ToString(), out var l)) logical = Math.Max(logical, l);
                }
            }
            catch { }

            // RAM via WMI (GB)
            int ramGB = 0;
            try
            {
                using var mos = new ManagementObjectSearcher("select TotalVisibleMemorySize from Win32_OperatingSystem");
                foreach (var o in mos.Get())
                {
                    if (ulong.TryParse(o["TotalVisibleMemorySize"]?.ToString(), out var kb))
                        ramGB = (int)(kb / 1024 / 1024);
                }
            }
            catch { }

            // GPU via DLL fallback or WMI
            string gpuName = getGpuNameFallback();
            int vramGB = 0;
            try
            {
                using var mos = new ManagementObjectSearcher("select Name, AdapterRAM from Win32_VideoController");
                foreach (var o in mos.Get())
                {
                    string n = (o["Name"]?.ToString() ?? "").Trim();
                    if (!string.IsNullOrEmpty(n)) gpuName = n;
                    if (ulong.TryParse(o["AdapterRAM"]?.ToString(), out var bytes))
                        vramGB = (int)(bytes / (1024 * 1024 * 1024));
                }
            }
            catch { }

            int primaryHz = 0;
            try { primaryHz = getPrimaryHz(); } catch { }

            return new HWInfo(cpuName, logical, physical, ramGB, gpuName, vramGB, primaryHz);
        }

        private static string Normalize(string s) => (s ?? "").ToUpperInvariant();

        private string MatchTierForGpu(string gpuName, int vramGB)
        {
            var gpus = _db?["gpus"]?.AsArray();
            string g = Normalize(gpuName);
            if (gpus != null)
            {
                foreach (var node in gpus)
                {
                    var pat = Normalize(node?["pattern"]?.ToString() ?? "");
                    if (string.IsNullOrEmpty(pat)) continue;
                    if (g.Contains(pat))
                    {
                        var minVram = node?["vram_min_gb"]?.GetValue<int?>() ?? 0;
                        var tier = node?["tier"]?.ToString() ?? "medium";
                        if (minVram > 0 && vramGB > 0 && vramGB < minVram) return "medium";
                        return tier;
                    }
                }
            }
            // fallback by VRAM
            if (vramGB >= 16) return "high";
            if (vramGB >= 8) return "medium";
            return "low";
        }

        private string MatchTierForCpu(string cpuName, int physicalCores)
        {
            var cpus = _db?["cpus"]?.AsArray();
            string c = Normalize(cpuName);
            if (cpus != null)
            {
                foreach (var node in cpus)
                {
                    var pat = Normalize(node?["pattern"]?.ToString() ?? "");
                    if (string.IsNullOrEmpty(pat)) continue;
                    if (c.Contains(pat))
                    {
                        var minCores = node?["cores_min"]?.GetValue<int?>() ?? 0;
                        var tier = node?["tier"]?.ToString() ?? "medium";
                        if (minCores > 0 && physicalCores > 0 && physicalCores < minCores) return "medium";
                        return tier;
                    }
                }
            }
            if (physicalCores >= 12) return "high";
            if (physicalCores >= 6) return "medium";
            return "low";
        }

        private string FloorByRam(int ramGB, string tier)
        {
            var rules = _db?["ram_rules"]?.AsArray();
            string best = "low";
            if (rules != null)
            {
                foreach (var r in rules)
                {
                    int min = r?["ram_gb_min"]?.GetValue<int?>() ?? 0;
                    string floor = r?["tier_floor"]?.ToString() ?? "low";
                    if (ramGB >= min) best = floor;
                }
            }
            // pick the worst between current tier and floor? No, ensure at least the floor.
            return RankTier(tier) < RankTier(best) ? tier : best;
        }

        private static int RankTier(string t) => t switch { "ultra" => 4, "high" => 3, "medium" => 2, _ => 1 };

        private int PickFpsCap(int primaryHz)
        {
            var arr = _db?["monitors"]?.AsArray();
            int cap = 60;
            if (arr != null)
            {
                foreach (var r in arr)
                {
                    int hzMin = r?["hz_min"]?.GetValue<int?>() ?? 0;
                    int fps = r?["fps_cap"]?.GetValue<int?>() ?? 60;
                    if (primaryHz >= hzMin) { cap = fps; break; }
                }
            }
            return cap;
        }

        public Recommendation Recommend(HWInfo hw)
        {
            string gpuTier = MatchTierForGpu(hw.GpuName, hw.GpuVramGB);
            string cpuTier = MatchTierForCpu(hw.CpuName, hw.PhysicalCores);
            string baseTier = RankTier(gpuTier) <= RankTier(cpuTier) ? gpuTier : cpuTier;
            string tier = FloorByRam(hw.RamGB, baseTier);

            int fpsCap = PickFpsCap(hw.PrimaryHz);

            string iniSk = GetGameIni("Skyrim", tier, fpsCap);
            string iniFo4 = GetGameIni("Fallout4", tier, fpsCap);
            string iniSf = GetGameIni("Starfield", tier, fpsCap);
            string iniObr = GetGameIni("OblivionRemastered", tier, fpsCap);

            return new Recommendation(tier, fpsCap, iniSk, iniFo4, iniSf, iniObr);
        }

        private string GetGameIni(string game, string tier, int fps)
        {
            var profiles = _db?["game_profiles"]?[game]?.AsObject();
            string tmpl = profiles?[tier]?.ToString() ?? "";
            return tmpl.Replace("{FPS}", fps.ToString());
        }
    }
}
