(function(){
  const inflight=new Map();
  function uuid(){return Math.random().toString(36).slice(2)+Date.now().toString(36);}
  window.boBridge={request:function(cmd,payload){return new Promise((res)=>{const id=uuid();inflight.set(id,res);chrome.webview.postMessage(JSON.stringify({id,cmd,payload}));});}};
  chrome.webview.addEventListener('message',ev=>{try{const m=JSON.parse(ev.data);const f=inflight.get(m.id);if(f){inflight.delete(m.id);f(m.data);}}catch(e){console.warn('bridge parse',e);}});
})();

// --- Cleanup: remove stray raw-JS text blocks accidentally rendered at top of the page ---
document.addEventListener('DOMContentLoaded', () => {
  try {
    const body = document.body;
    // Remove empty whitespace-only text nodes
    for (const n of Array.from(body.childNodes)) {
      if (n.nodeType === Node.TEXT_NODE) {
        const t = (n.textContent || "").trim();
        const looksLikeJS = t.length > 200 && /(?:\bconst\b|\bvar\b|\blet\b|\bfunction\b)/.test(t) && /[;{}()=]/.test(t);
        if (!t || looksLikeJS) n.remove();
        else break;
      } else {
        break;
      }
    }
  } catch (e) {
    console.warn('cleanup failed', e);
  }
});
